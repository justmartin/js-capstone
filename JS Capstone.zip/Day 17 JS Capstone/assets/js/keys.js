$(document).ready(function() {

	$("#a").click(function() {
		a = $("#a")[0].value;
		storeGuessedLetters(a);
		guessClickedLetter(a);
		$("#a").attr("disabled", "true");
		subtractGuesses();
	});

	$("#b").click(function() {
		b = $("#b")[0].value;
		storeGuessedLetters(b);
		guessClickedLetter(b);
		$("#b").attr("disabled", "true");
		subtractGuesses();
	});
	
	$("#c").click(function() {
		c = $("#c")[0].value;
		storeGuessedLetters(c);
		guessClickedLetter(c);
		$("#c").attr("disabled", "true");
		subtractGuesses();
	});

	$("#d").click(function() {
		d = $("#d")[0].value;
		storeGuessedLetters(d);
		guessClickedLetter(d);
		$("#d").attr("disabled", "true");
		subtractGuesses();
	});

	$("#e").click(function() {
		e = $("#e")[0].value;
		storeGuessedLetters(e);
		guessClickedLetter(e);
		$("#e").attr("disabled", "true");
		subtractGuesses();
	});

	$("#f").click(function() {
		f = $("#f")[0].value;
		storeGuessedLetters(f);
		guessClickedLetter(f);
		$("#f").attr("disabled", "true");
		subtractGuesses();
	});
	
	$("#g").click(function() {
		g = $("#g")[0].value;
		storeGuessedLetters(g);
		guessClickedLetter(g);
		$("#g").attr("disabled", "true");
		subtractGuesses();
	});

	$("#h").click(function() {
		h = $("#h")[0].value;
		storeGuessedLetters(h);
		guessClickedLetter(h);
		$("#h").attr("disabled", "true");
		subtractGuesses();
	});

	$("#i").click(function() {
		i = $("#i")[0].value;
		storeGuessedLetters(i);
		guessClickedLetter(i);
		$("#i").attr("disabled", "true");
		subtractGuesses();
	});

	$("#j").click(function() {
		j = $("#j")[0].value;
		storeGuessedLetters(j);
		guessClickedLetter(j);
		$("#j").attr("disabled", "true");
		subtractGuesses();
	});
	
	$("#k").click(function() {
		k = $("#k")[0].value;
		storeGuessedLetters(k);
		guessClickedLetter(k);
		$("#k").attr("disabled", "true");
		subtractGuesses();
	});

	$("#l").click(function() {
		l = $("#l")[0].value;
		storeGuessedLetters(l);
		guessClickedLetter(l);
		$("#l").attr("disabled", "true");
		subtractGuesses();
	});

	$("#m").click(function() {
		m = $("#m")[0].value;
		storeGuessedLetters(m);
		guessClickedLetter(m);
		$("#m").attr("disabled", "true");
		subtractGuesses();
	});

	$("#n").click(function() {
		n = $("#n")[0].value;
		storeGuessedLetters(n);
		guessClickedLetter(n);
		$("#n").attr("disabled", "true");
		subtractGuesses();
	});
	
	$("#o").click(function() {
		o = $("#o")[0].value;
		storeGuessedLetters(o);
		guessClickedLetter(o);
		$("#o").attr("disabled", "true");
		subtractGuesses();
	});

	$("#p").click(function() {
		p = $("#p")[0].value;
		storeGuessedLetters(p);
		guessClickedLetter(p);
		$("#p").attr("disabled", "true");
		subtractGuesses();
	});

	$("#q").click(function() {
		q = $("#q")[0].value;
		storeGuessedLetters(q);
		guessClickedLetter(q);
		$("#q").attr("disabled", "true");
		subtractGuesses();
	});

	$("#r").click(function() {
		r = $("#r")[0].value;
		storeGuessedLetters(r);
		guessClickedLetter(r);
		$("#r").attr("disabled", "true");
		subtractGuesses();
	});
	
	$("#s").click(function() {
		s = $("#s")[0].value;
		storeGuessedLetters(s);
		guessClickedLetter(s);
		$("#s").attr("disabled", "true");
		subtractGuesses();
	});

	$("#t").click(function() {
		t = $("#t")[0].value;
		storeGuessedLetters(t);
		guessClickedLetter(t);
		$("#t").attr("disabled", "true");
		subtractGuesses();
	});


	$("#u").click(function() {
		u = $("#u")[0].value;
		storeGuessedLetters(u);
		guessClickedLetter(u);
		$("#u").attr("disabled", "true");
		subtractGuesses();
	});

	$("#v").click(function() {
		v = $("#v")[0].value;
		storeGuessedLetters(v);
		guessClickedLetter(v);
		$("#v").attr("disabled", "true");
		subtractGuesses();
	});

	$("#w").click(function() {
		w = $("#w")[0].value;
		storeGuessedLetters(w);
		guessClickedLetter(w);
		$("#w").attr("disabled", "true");
		subtractGuesses();
	});

	$("#x").click(function() {
		x = $("#x")[0].value;
		storeGuessedLetters(x);
		guessClickedLetter(x);
		$("#x").attr("disabled", "true");
		subtractGuesses();
	});

	$("#y").click(function() {
		y = $("#y")[0].value;
		storeGuessedLetters(y);
		guessClickedLetter(y);
		$("#y").attr("disabled", "true");
		subtractGuesses();
	});

	$("#z").click(function() {
		z = $("#z")[0].value;
		storeGuessedLetters(z);
		guessClickedLetter(z);
		$("#z").attr("disabled", "true");
		subtractGuesses();
	});
		
});